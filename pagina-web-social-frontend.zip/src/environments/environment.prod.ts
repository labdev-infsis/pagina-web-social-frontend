export const environment = {
  production: true,
  BACK_END_HOST: '',
};
