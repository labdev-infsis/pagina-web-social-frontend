export class ResetPassword {
    email?: string;
    password?: string;
}