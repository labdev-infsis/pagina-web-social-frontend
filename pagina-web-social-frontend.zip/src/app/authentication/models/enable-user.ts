export class EnableUser {
    email?: string;
    enable?: boolean;
}